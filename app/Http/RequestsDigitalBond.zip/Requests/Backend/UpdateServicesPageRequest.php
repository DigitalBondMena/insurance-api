<?php

namespace App\Http\Requests\Backend;

use Illuminate\Foundation\Http\FormRequest;

class UpdateServicesPageRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'en_services_title' => 'required',
            'ar_services_title' => 'required',
            'en_services_text' => 'required',
            'ar_services_text' => 'required',
            'en_services_we_work_title' => 'required',
            'ar_services_we_work_title' => 'required',

            'en_services_we_work_first_tab_title' => 'required',
            'ar_services_we_work_first_tab_title' => 'required',
            'en_services_we_work_first_tab_first_paragraph' => 'required',
            'ar_services_we_work_first_tab_first_paragraph' => 'required',
            'en_services_we_work_first_tab_second_paragraph' => 'required',
            'ar_services_we_work_first_tab_second_paragraph' => 'required',
            'en_services_we_work_first_tab_first_li_item' => 'required',
            'ar_services_we_work_first_tab_first_li_item' => 'required',
            'en_services_we_work_first_tab_second_li_item' => 'required',
            'ar_services_we_work_first_tab_second_li_item' => 'required',
            'en_services_we_work_first_tab_third_li_item' => 'required',
            'ar_services_we_work_first_tab_third_li_item' => 'required',

            'en_services_we_work_second_tab_title' => 'required',
            'ar_services_we_work_second_tab_title' => 'required',
            'en_services_we_work_second_tab_first_paragraph' => 'required',
            'ar_services_we_work_second_tab_first_paragraph' => 'required',
            'en_services_we_work_second_tab_second_paragraph' => 'required',
            'ar_services_we_work_second_tab_second_paragraph' => 'required',
            'en_services_we_work_second_tab_first_li_item' => 'required',
            'ar_services_we_work_second_tab_first_li_item' => 'required',
            'en_services_we_work_second_tab_second_li_item' => 'required',
            'ar_services_we_work_second_tab_second_li_item' => 'required',
            'en_services_we_work_second_tab_third_li_item' => 'required',
            'ar_services_we_work_second_tab_third_li_item' => 'required',

            'en_services_we_work_third_tab_title' => 'required',
            'ar_services_we_work_third_tab_title' => 'required',
            'en_services_we_work_third_tab_first_paragraph' => 'required',
            'ar_services_we_work_third_tab_first_paragraph' => 'required',
            'en_services_we_work_third_tab_second_paragraph' => 'required',
            'ar_services_we_work_third_tab_second_paragraph' => 'required',
            'en_services_we_work_third_tab_first_li_item' => 'required',
            'ar_services_we_work_third_tab_first_li_item' => 'required',
            'en_services_we_work_third_tab_second_li_item' => 'required',
            'ar_services_we_work_third_tab_second_li_item' => 'required',
            'en_services_we_work_third_tab_third_li_item' => 'required',
            'ar_services_we_work_third_tab_third_li_item' => 'required',

            'en_services_contact_us_first_part' => 'required',
            'ar_services_contact_us_first_part' => 'required',
            'en_services_contact_us_second_part' => 'required',
            'ar_services_contact_us_second_part' => 'required',

            'services_we_work_first_tab_image' => 'mimes:jpg,jpeg,png,svg',
            'services_we_work_second_tab_image' => 'mimes:jpg,jpeg,png,svg',
            'services_we_work_third_tab_image' => 'mimes:jpg,jpeg,png,svg',
        ];
    }
}
