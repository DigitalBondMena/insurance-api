<?php

namespace App\Http\Requests\Backend;

use Illuminate\Foundation\Http\FormRequest;

class StoreMainRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'ar_services_title' => 'required',
            'en_service_title' => 'required',
            'ar_services_text' => 'required',
            'en_services_text' => 'required',
            'ar_about_title' => 'required',
            'en_about_title' => 'required',
            'ar_about_first_paragraph' => 'required',
            'en_about_first_paragraph' => 'required',
            'ar_about_second_paragraph' => 'required',
            'en_about_second_paragraph' => 'required',
            'ar_about_first_li_item' => 'required',
            'en_about_first_li_item' => 'required',
            'ar_about_secont_li_item' => 'required',
            'en_about_secont_li_item' => 'required',
            'ar_about_third_li_item' => 'required',
            'en_about_third_li_item' => 'required',
            'home_about_first_image' => 'required|mimes:jpg,jpeg,png,svg',
            'home_about_second_image' => 'required|mimes:jpg,jpeg,png,svg',
            'ar_home_video_title' => 'required',
            'en_home_video_title' => 'required',
            'home_video_url' => 'required|url',
            'home_video_image' => 'required|mimes:jpg,jpeg,png,svg',
            'ar_home_we_do_title' => 'required',
            'en_home_we_do_title' => 'required',
            'ar_home_we_do_text' => 'required',
            'en_home_we_do_text' => 'required',
            'home_we_do_image' => 'required|mimes:jpg,jpeg,png,svg',
            'home_we_do_precent' => 'required',
            'ar_home_we_do_first_title' => 'required',
            'en_home_we_do_first_title' => 'required',
            'ar_home_we_do_second_title' => 'required',
            'en_home_we_do_second_title' => 'required',
            'ar_home_we_do_third_title' => 'required',
            'en_home_we_do_third_title' => 'required',
            'ar_home_we_do_first_text' => 'required',
            'en_home_we_do_first_text' => 'required',
            'ar_home_we_do_second_text' => 'required',
            'en_home_we_do_second_text' => 'required',
            'ar_home_we_do_third_text' => 'required',
            'en_home_we_do_third_text' => 'required',
            'ar_home_quote_title' => 'required',
            'en_home_quote_title' => 'required',
            'home_quote_image'=>'required|mimes:jpg,jpeg,png,svg',
            'home_quote_banner_image' =>'required|mimes:jpg,jpeg,png,svg',
            'ar_home_contact_first_part' => 'required',
            'en_home_contact_first_part' => 'required',
            'ar_home_contact_second_part' => 'required',
            'en_home_contact_second_part' => 'required',
            'ar_home_facts_first_li_item_title' => 'required',
            'en_home_facts_first_li_item_title' => 'required',
            'home_facts_first_li_item_number' => 'required',
            'ar_home_facts_second_li_item_title' => 'required',
            'en_home_facts_second_li_item_title' => 'required',
            'home_facts_second_li_item_number' => 'required',
            'ar_home_facts_third_li_item_title' => 'required',
            'en_home_facts_third_li_item_title' => 'required',
            'home_facts_third_li_item_number' => 'required',
            'ar_home_facts_fourth_li_item_title' => 'required',
            'en_home_facts_fourth_li_item_title' => 'required',
            'home_facts_fourth_li_item_number' => 'required',
            'ar_home_facts_header_inner_title' => 'required',
            'en_home_facts_header_inner_title' => 'required',
            'ar_home_facts_features_first_title' => 'required',
            'en_home_facts_features_first_title' => 'required',
            'ar_home_facts_features_first_sub_title' => 'required',
            'en_home_facts_features_first_sub_title' => 'required',
            'ar_home_facts_features_second_title' => 'required',
            'en_home_facts_features_second_title' => 'required',
            'ar_home_facts_features_second_sub_title' => 'required',
            'en_home_facts_features_second_sub_title' => 'required',
            'ar_home_facts_features_header_outer_title' => 'required',
            'en_home_facts_features_header_outer_title' => 'required',
            'ar_home_facts_features_header_outer_text' => 'required',
            'en_home_facts_features_header_outer_text' => 'required',
            'home_facts_features_header_outer_image' => 'required|mimes:jpg,jpeg,png,svg',
            'ar_home_facts_features_header_first_li_itme' => 'required',
            'en_home_facts_features_header_first_li_itme' => 'required',
            'ar_home_facts_features_header_second_li_itme' => 'required',
            'en_home_facts_features_header_second_li_itme' => 'required',
            'ar_home_facts_features_header_third_li_itme' => 'required',
            'en_home_facts_features_header_third_li_itme' => 'required',
            'ar_home_facts_features_header_fourth_li_itme' => 'required',
            'en_home_facts_features_header_fourth_li_itme' => 'required',
            
             ];
    }
}
