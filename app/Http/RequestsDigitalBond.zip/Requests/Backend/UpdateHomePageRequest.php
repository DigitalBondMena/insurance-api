<?php

namespace App\Http\Requests\Backend;

use Illuminate\Foundation\Http\FormRequest;

class UpdateHomePageRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            
            'en_about_home_title' => 'required',
            'ar_about_home_title' => 'required',
            'en_about_home_text' => 'required',
            'ar_about_home_text' => 'required',
            
            'en_first_icon_title' => 'required',
            'ar_first_icon_title' => 'required',
            'first_icon' => 'mimes:jpg,jpeg,png,svg',
            
            'en_second_icon_title' => 'required',
            'ar_second_icon_title' => 'required',
            'second_icon' => 'mimes:jpg,jpeg,png,svg',
            
            'en_third_icon_title' => 'required',
            'ar_third_icon_title' => 'required',
            'third_icon' => 'mimes:jpg,jpeg,png,svg',
            
            'en_fourth_icon_title' => 'required',
            'ar_fourth_icon_title' => 'required',
            'fourth_icon' => 'mimes:jpg,jpeg,png,svg',
            
            
        ];
    }
}
