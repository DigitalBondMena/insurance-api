<?php

namespace App\Http\Requests\Backend;

use Illuminate\Foundation\Http\FormRequest;

class UpdateAboutRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'en_about_title' => 'required',
            'ar_about_title' => 'required',
            'en_about_text' => 'required',
            'ar_about_text' => 'required',
            'about_image' => 'mimes:jpg,jpeg,png,svg',
            'about_banner_image' => 'mimes:jpg,jpeg,png,svg',
            'en_mission_title' => 'required',
            'ar_mission_title' => 'required',
            'en_mission_text' => 'required',
            'ar_mission_text' => 'required',
            'en_vision_title' => 'required',
            'ar_vision_title' => 'required',  
            'en_vision_text' => 'required',
            'ar_vision_text' => 'required',
            'en_history_title' => 'required',
            'ar_history_title' => 'required',  
            'en_history_text' => 'required',
            'ar_history_text' => 'required',
        ];
    }
}
