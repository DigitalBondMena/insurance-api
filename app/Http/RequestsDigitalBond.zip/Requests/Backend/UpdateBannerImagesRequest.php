<?php

namespace App\Http\Requests\Backend;

use Illuminate\Foundation\Http\FormRequest;

class UpdateBannerImagesRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'services_banner_image' => 'mimes:jpg,jpeg,png,svg',
            'services_detail_banner_image' => 'mimes:jpg,jpeg,png,svg',
            'say_hello_banner_image' => 'mimes:jpg,jpeg,png,svg',
            'feedback_banner_image' => 'mimes:jpg,jpeg,png,svg',
            'contact_banner_image' => 'mimes:jpg,jpeg,png,svg',
        ];
    }
}
