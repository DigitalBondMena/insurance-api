<?php

namespace App\Http\Requests\Backend;

use Illuminate\Foundation\Http\FormRequest;

class UpdateContactUsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email' => 'required|email',
            'en_location' => 'required',
            'ar_location' => 'required',
            'en_address' => 'required',
            'ar_address' => 'required',
            'phone' => 'required',
            'en_work_days' => 'required',
            'ar_work_days' => 'required',
            'en_work_hours' => 'required',
            'ar_work_hours' => 'required',
            'facebook' => 'required|url',
            'twitter' => 'required|url',
            'instagram' => 'required|url',
            'banner_image' => 'mimes:jpg,jpeg,png,svg',
        ];
    }
}
