<?php

namespace App\Http\Requests\Backend;

use Illuminate\Foundation\Http\FormRequest;

class UpdateAboutUsPageRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'about_banner_image'  => 'mimes:jpg,jpeg,png,svg',
            'about_section_image'  => 'mimes:jpg,jpeg,png,svg',
            'en_about_section_title'  => 'required',
            'ar_about_section_title'  => 'required',
            'en_about_section_text'  => 'required',
            'ar_about_section_text'  => 'required',
            'mission_vision_image'  => 'mimes:jpg,jpeg,png,svg',
            'en_vision_title'   => 'required',
            'ar_vision_title'  => 'required',
            'en_vision_text'  => 'required',
            'ar_vision_text'  => 'required',
            'en_mission_title'  => 'required',
            'ar_mission_title'  => 'required',
            'en_mission_text'  => 'required',
            'ar_mission_text'  => 'required',
        ];
    }
}
